package com.example.sightzapp

data class Custom(var title: String, var description: String, var image: Int)
