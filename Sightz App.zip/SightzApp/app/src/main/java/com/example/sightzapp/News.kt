package com.example.sightzapp

data class News(var titleImage : Int, var heading : String)